﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using MinhaApp.Models;
using MinhaApp.Validators;

namespace MinhaApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AlunoController : ControllerBase
    {
   
        private static readonly List<Aluno> _alunos = new();

        [HttpGet("{id:int}")]
        public IActionResult GetById(int id)
        {
            var aluno = _alunos.FirstOrDefault(a => a.Id == id);
            if (aluno == null)
                return NotFound(new { Mensagem = "Aluno não encontrado." });

            return Ok(aluno);
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(_alunos);
        }

        [HttpPost]
        public IActionResult Create([FromBody] Aluno aluno)
        {
        
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (_alunos.Any(a => a.RA == aluno.RA))
            {
                ModelState.AddModelError("RA", "Este RA já está cadastrado.");
                return BadRequest(ModelState);
            }

            if (_alunos.Any(a => a.Email.Equals(aluno.Email, System.StringComparison.OrdinalIgnoreCase)))
            {
                ModelState.AddModelError("Email", "Este email já está cadastrado.");
                return BadRequest(ModelState);
            }

            aluno.Id = _alunos.Count > 0 ? _alunos.Max(a => a.Id) + 1 : 1;
            _alunos.Add(aluno);

            return CreatedAtAction(nameof(GetById), new { id = aluno.Id }, aluno);
        }

        [HttpPut("{id:int}")]
        public IActionResult Update(int id, [FromBody] Aluno updated)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var existing = _alunos.FirstOrDefault(a => a.Id == id);
            if (existing == null)
                return NotFound(new { Mensagem = "Aluno não encontrado." });

            existing.Nome = updated.Nome;
            existing.RA = updated.RA;
            existing.Email = updated.Email;
            existing.Cpf = updated.Cpf;
            existing.Ativo = updated.Ativo;

            return Ok(existing);
        }

        [HttpDelete("{id:int}")]
        public IActionResult Delete(int id)
        {
            var existing = _alunos.FirstOrDefault(a => a.Id == id);
            if (existing == null)
                return NotFound(new { Mensagem = "Aluno não encontrado." });

            _alunos.Remove(existing);
            return NoContent();
        }
    }
}