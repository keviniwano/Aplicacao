﻿using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace MinhaApp.Validators
{
    public class RAValidationAttribute : ValidationAttribute
    {
        protected override ValidationResult? IsValid(object value, ValidationContext validationContext)
        {
            var ra = value as string ?? string.Empty;

            if (string.IsNullOrWhiteSpace(ra))
                return new ValidationResult("RA é obrigatório");

            if (!ra.StartsWith("RA"))
                return new ValidationResult("RA deve começar com 'RA'");

            var rest = ra.Substring(2);
            if (rest.Length != 6)
                return new ValidationResult("RA deve conter 6 dígitos após 'RA'");

            if (!Regex.IsMatch(rest, @"^\d{6}$"))
                return new ValidationResult("RA deve conter apenas dígitos após 'RA'");

            return ValidationResult.Success;
        }
    }
}