﻿using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.RegularExpressions;

namespace MinhaApp.Validators
{
    public class CPFValidationAttribute : ValidationAttribute
    {
        protected override ValidationResult? IsValid(object value, ValidationContext validationContext)
        {
            var cpf = value as string ?? string.Empty;
            if (string.IsNullOrWhiteSpace(cpf))
                return new ValidationResult("CPF é obrigatório");

            var digits = new string(cpf.Where(char.IsDigit).ToArray());

            if (digits.Length != 11 || !Regex.IsMatch(digits, @"^\d{11}$"))
                return new ValidationResult("CPF deve conter 11 dígitos numéricos");

            return ValidationResult.Success;
        }
    }
}