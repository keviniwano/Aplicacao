﻿using MinhaApp.Validators;
using System.ComponentModel.DataAnnotations;

namespace MinhaApp.Models
{
    public class Aluno
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Nome é obrigatório")]
        [StringLength(100, MinimumLength = 3, ErrorMessage = "Nome deve ter no mínimo 3 caracteres")]
        public string Nome { get; set; } = string.Empty;

        [Required(ErrorMessage = "RA é obrigatório")]
        [RAValidation]
        public string RA { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email é obrigatório")]
        [EmailAddress(ErrorMessage = "Email inválido")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "CPF é obrigatório")]
        [CPFValidation]
        public string Cpf { get; set; } = string.Empty;

        [Required(ErrorMessage = "Ativo é obrigatório")]
        public bool Ativo { get; set; }
    }
}